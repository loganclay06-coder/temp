/*
 * Name: Logan Clay
 * Date: 11/21/2026
 * Temperature Conversion App
 */

package com.example.temperture

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etTemperature = findViewById<EditText>(R.id.etTemperature)
        val rbFtoC = findViewById<RadioButton>(R.id.rbFtoC)
        val btnConvert = findViewById<Button>(R.id.btnConvert)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnConvert.setOnClickListener {

            if (etTemperature.text.toString().isEmpty()) {
                Toast.makeText(this, "Enter a temperature value", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val temp = etTemperature.text.toString().toDouble()

            if (rbFtoC.isChecked) {

                if (temp < -100 || temp > 250) {
                    Toast.makeText(
                        this,
                        "Fahrenheit must be between -100 and 250",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                val celsius = (temp - 32) * 5 / 9
                tvResult.text = String.format("%.2f °C", celsius)

            } else {

                if (temp < -75 || temp > 125) {
                    Toast.makeText(
                        this,
                        "Celsius must be between -75 and 125",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                val fahrenheit = (temp * 9 / 5) + 32
                tvResult.text = String.format("%.2f °F", fahrenheit)
            }
        }
    }
}